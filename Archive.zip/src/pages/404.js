import * as React from 'react';

const NotFoundPage = () => {
  return (
    <main>
      <title>Not found</title>
      <div>hello</div>
    </main>
  );
};

export default NotFoundPage;
